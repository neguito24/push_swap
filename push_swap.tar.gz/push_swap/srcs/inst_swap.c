/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   inst_swap.c                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/20 15:21:25 by anrivera          #+#    #+#             */
/*   Updated: 2024/08/20 17:20:57 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

void	swap_stack(t_stack **stack)
{
	int	temp;

	if (stack != NULL && (*stack)->next != NULL)
	{
		temp = (*stack)->nbr;
		(*stack)->nbr = (*stack)-> next-> nbr;
		(*stack)->next->nbr = temp;
	}
}
