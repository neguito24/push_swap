/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_stack.c                                         :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/08/07 12:43:35 by anrivera          #+#    #+#             */
/*   Updated: 2024/08/12 14:57:57 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/push_swap.h"

// This function needs to return the list change it
t_stack	*ft_init_stack(char **arr, int index, int size, char mem)
{
	t_stack	*a;
	int		*nbr;
	int		i;

	a = NULL;
	i = 0;
	nbr = ft_check_constraints(arr, index, size, mem);
	if (ft_check_duplicates(nbr, size))
	{
		free(nbr);
		if (mem == 'Y')
			free_mem_arr(arr);
		ft_error();
	}
	while (i <= size)
	{
		ft_append_node(&a, nbr[i]);
		i++;
	}
	free(nbr);
	if (mem == 'Y')
		free_mem_arr (arr);
	if (a == NULL)
		return (NULL);
	return (a);
}

void	ft_append_node(t_stack **stack, int n)
{
	t_stack	*new_node;
	t_stack	*last_node;

	if (stack == NULL)
		return ;
	new_node = malloc (sizeof(t_stack));
	if (new_node == NULL)
		return ;
	new_node -> next = NULL;
	new_node -> nbr = n;
	if (*stack == NULL)
	{
		*stack = new_node;
		new_node -> prev = NULL;
	}
	else
	{
		last_node = ft_find_last_node(*stack);
		last_node -> next = new_node;
		new_node -> prev = last_node;
	}
}

t_stack	*ft_find_last_node(t_stack *list)
{
	if (list == NULL)
		return (NULL);
	while (list -> next)
		list = list -> next;
	return (list);
}

void	ft_free_stack(t_stack **stack)
{
	t_stack	*temp;

	if (stack == NULL)
		return ;
	while (*stack)
	{
		temp = (*stack)-> next;
		free(*stack);
		*stack = temp;
	}
}
