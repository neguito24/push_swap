/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_printf.h                                        :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/06/23 20:28:12 by anrivera          #+#    #+#             */
/*   Updated: 2024/07/02 18:43:18 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef FT_PRINTF_H
# define FT_PRINTF_H

# include <stdarg.h>
# include "./libft/libft.h"

int	ft_print_format(char c, va_list ap);
int	ft_printf(const char *format, ...);
int	ft_print_string(char *str);
int	ft_print_char(char c);
int	ft_print_pointer(unsigned long value, int asc);
int	ft_print_int(int nb);
int	ft_print_unsigned(unsigned int nb);
int	ft_print_hexa(unsigned int value, int ascc);
int	ft_print_special(void);
#endif