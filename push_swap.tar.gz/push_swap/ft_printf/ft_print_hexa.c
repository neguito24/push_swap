/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_hexa.c                                    :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/02 12:26:38 by anrivera          #+#    #+#             */
/*   Updated: 2024/07/02 17:41:44 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

static int	ft_count_hexa(unsigned int value)
{
	int				i;
	unsigned long	temp;

	i = 0;
	temp = value;
	if (temp == 0)
		return (1);
	while (temp != 0)
	{
		temp = temp / 16;
		i++;
	}
	return (i);
}

static void	ft_puthexa_fd(unsigned int value, int ascc, int fd)
{
	if (value > 15)
	{
		ft_puthexa_fd(value / 16, ascc, fd);
	}
	if ((value % 16) < 10)
		ft_putchar_fd((value % 16) + 48, fd);
	else
		ft_putchar_fd((value % 16) + ascc, fd);
}

int	ft_print_hexa(unsigned int value, int ascc)
{
	ft_puthexa_fd(value, ascc, 1);
	return (ft_count_hexa(value));
}
