/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   ft_print_int.c                                     :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2024/07/02 11:14:56 by anrivera          #+#    #+#             */
/*   Updated: 2024/07/02 11:29:38 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "ft_printf.h"

int	ft_print_int(int nb)
{
	int				number;
	unsigned int	i;

	number = nb;
	i = 1;
	if (nb < 0 && nb != -2147483648)
	{
		number = -nb;
		i++;
	}
	while (number > 9)
	{
		number = number / 10;
		i++;
	}
	ft_putnbr_fd(nb, 1);
	if (nb == -2147483648)
		return (11);
	return (i);
}
